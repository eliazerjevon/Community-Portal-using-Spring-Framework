package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.beans.User;
import com.example.demo.service.UserService;

@SpringBootTest
class DemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
