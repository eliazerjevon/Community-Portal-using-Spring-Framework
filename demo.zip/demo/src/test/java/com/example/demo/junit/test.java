package com.example.demo.junit;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.beans.User;
import com.example.demo.service.UserService;

@SpringBootTest
class test {
	@Autowired
	UserService userService;

	@Test
	void register() {
		User user = new User();
		user.setUsername("skeleton");
		user.setEmail("eliazer@gmail.com");
		user.setFirstName("Eliazer");
		user.setLastName("Jevon");
		user.setPassword("qwerty123");
		user.setAddress("Enola street");
		user.setContact("6281523825");
		userService.addUserDetail(user);
		System.out.println(user);
		assertThat(user).isNotNull();
	}
	
	@Test
	void search() {
		List<User> users=userService.showUser("a");
		System.out.println(users);
		assertThat(users).isNotEmpty();
	}

}
